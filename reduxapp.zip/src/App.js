import { useDispatch, useSelector } from 'react-redux';
import './App.css';
import { Fetch_FakeStore_Data } from './redux/actions/Agency';
import { useEffect } from 'react';

function App() {

  const dispatch = useDispatch();
  const fakeStoreData = useSelector((state) => state.Agency.fakeStoreData);
  fakeStoreData && console.log(fakeStoreData)
  
  useEffect(() => {
    // if (fakeStoreData.length === 0) dispatch(Fetch_FakeStore_Data());
    dispatch(Fetch_FakeStore_Data());
  }, []);

  return (
    <div className="App">
      <h1>This is Dev Tiwari</h1>
    </div>
  );
}

export default App;

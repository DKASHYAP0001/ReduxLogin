import { Get_Fake_Store_Product } from "../actionTypes"

const initialState = {
    fakeStoreData: [],
}

const AgencyReducer = (state = initialState, action) => {
    switch (action.type) {
        case Get_Fake_Store_Product:
            return {
                ...state,
                fakeStoreData: action.payload
            }
        default: return state
    }
}
export default AgencyReducer

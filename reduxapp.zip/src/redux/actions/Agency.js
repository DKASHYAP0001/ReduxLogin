import { Get_Fake_Store_Product } from '../actionTypes';
import * as api from '../api'

export const Fetch_FakeStore_Data = async (dispatch) => {
    try {
        const fakeStoreData = await api.get_FakeStoreData_Api()
        console.log(fakeStoreData);
        dispatch({
            type: Get_Fake_Store_Product,
            payload: fakeStoreData
        });
    } catch (error) {
        console.log(error)
    }
}